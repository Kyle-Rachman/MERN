import './App.css'

function App() {

  return (
    <>
      <h1>Hello Dojo!</h1>
      <h2>Things I need to do:</h2>
      <ul>
        <li>Solve a Rubik's Cube without looking up how</li>
        <li>Become a master climber</li>
        <li>Write a book</li>
        <li>Forge a sword</li>
      </ul>
    </>
  )
}

export default App
